/*********************************
* Class: MAGSHIMIM C2			 *
* Week 3           				 *
* HW solution   			 	 *
**********************************/
#include <stdio.h>
#include <string.h>

void printArray(char* p, int len)
{
	int i = 0;
	for(i = 0; i < len; i++ ) // תנאי הלולאה תמיד יהיה נכון 
	{
		printf("%c", *(p + i));
	}
	printf("\n");
}

int main(void)
{
	char msg[] = "hi jyegq meet me at 2 :)";// מכריזים על מערך רק בעזרת סוגריים מרובעות
	printArray(msg, strlen(msg));
    getchar();
    getchar();
	return 0;
 }

 // daniel want to meet jyegq
