#include <stdio.h>

void arrayInput(int* arr, int size);
void arrayEvenElements(int* arr, int size);
void arrayEvenElements(int* arr, int size);

#define SIZE 8

int main()
{
    int arr[SIZE] = {0};
    arrayInput(arr, SIZE);
    arrayEvenElements(arr, SIZE);
    
    getchar();
    getchar();
    return 0;
}
/*
the function gets input to an array
input: array pointer, size
output: none
*/
void arrayInput(int* arr, int size)
{
    int i = 0;
    printf("Enter %d numbers: ");
    for(i = 0; i < size; i++)
    {
        scanf("%d", arr + i);
    }
}
/*
print the even elementes in an array
input: array pointer, int size
output: none
*/
void arrayEvenElements(int* arr, int size)
{
    int i = 0;
    printf("The numbers in even indexes are: ");
    for(i = 0; i < 8; i += 2)
    {
        printf("%d ", *(arr + i));
    }
    printf("\n");
}