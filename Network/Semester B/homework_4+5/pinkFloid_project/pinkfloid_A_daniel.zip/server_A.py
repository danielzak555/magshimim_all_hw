import socket

LIS_PORT = 64999
HELLO = "Welcome to the Pink-Floyd Server!"
QUIT = 8
DEF_ANS = "the server recived op: "

def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('0.0.0.0', LIS_PORT)) 
    sock.listen(1)#listen for a massage

    over = False

    print("running on port 64999... Waiting for a connection...\n")
    client_socket, client_address = sock.accept()#creat socket with client and getting his details
    print(f"Connected with: {client_address}\n")# for us to know the connection is succsesful

    client_socket.sendall(HELLO.encode())

    while(over == False):

        try:
            request = client_socket.recv(1024)
        except Exception as e:
            print("client unexpectadly disconnected")
            break
     
        request_text = request.decode()
        print("Received request:")
        print(request_text)

        try:
            ser_ans = f"OK{request_text[2]}@{DEF_ANS}{request_text[2]}"
            client_socket.sendall(ser_ans.encode())#sending back to the client the answer from the server
            if(int(request_text[2]) == QUIT):   
                print("client asked to quit")
                over = True
        except Exception as e:
            print("client unexpectadly disconnected")
            sock.listen(1)
            print("running on port 64999... Waiting for a connection...\n")
            client_socket, client_address = sock.accept()
            print(f"Connected with: {client_address}\n")
            client_socket.sendall(HELLO.encode())


    client_socket.close()
    sock.close()

if __name__ == "__main__":
    main()      