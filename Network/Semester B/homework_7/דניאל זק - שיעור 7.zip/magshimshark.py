from scapy.all import *

def filter_the_dns(packet):
    """
    the fun filter the DNS packkets from the sniff
    :param packet: packet from the sniff
    :type packet: packet
    :return: false is not dns, true if its dns
    :rtype: bool
    """
    if DNS in packet:
        if packet[DNS].ancount >= 1:
            for record in packet[DNS].an:
                if record.type == 1:
                    return True
    return False

def print_dns(packet):
    """
    the fun prints the ip and domain from the DNS
    :param packet: packet from the sniff
    :type packet: packet
    :return: none
    """
    domain = packet[DNS].qd.qname.decode()
    ip = ''
    for record in packet[DNS].an:
        if record.type == 1:
            ip = record.rdata
    print("domain "+ domain + "ip " + ip)

def filter_the_weather(packet):
    """
    the fun filtering the "weather client" packets 
    :param packet: packet from the sniff
    :type packet: packet
    :return: true if the packet is weather client, if not then false
    :rtype: bool
    """
    if IP in packet:
        if packet[IP].src == '34.218.16.79' and Raw in packet:
            if 'Welcome' not in packet[Raw].load.decode():
                return True
    return False

def weather_print_answer(packet):
    """
    the fun print the weather client answer
    :param packet: a weather clint packet 
    :type packet: packet
    :return: none
    """
    response = packet[Raw].load.decode()
    print(response)

def http_filter(packet):
    """
    the fun filter the http packets
    :param packet: packet froom the sniff
    :type packet: packet
    :return: false is not http, is http return true
    :rtype: bool
    """
    if TCP in packet:
        if packet[TCP].dport == 80:
            if Raw in packet:
                if 'GET' in packet[Raw].load.decode():
                    return True
    return False

def print_http(packet):
    """
    the fun print the wanted http part
    :param packet: http packet from the sniff
    :type packet: packet
    :return: none
    """
    data = packet[Raw].load.decode()
    first_index = str(data).index("GET ")
    last_index = str(data).index(" HTTP")
    first_index += len("GET ")
    address = data[first_index:last_index]
    print(address)


def choise_and_menu():
    """
    the fun printing the menu
    :return: the choise
    :rtype: str
    """
    choice = 5
    print('Enter what to sniff: ')
    print('1. DNS')
    print('2. Forecast')
    print('3. HTTP')
    print('4. E-mails')
    while choice < 0 or choice > 4:
        try:
            choice = int(input('0 to Exit: '))
            if choice < 0 or choice > 4:
                print('Invalid choice')
        except Exception as e:
            print('Error: ' + str(e))
    return str(choice)


def main():
    FILTER = {
        '1': filter_the_dns,
        '2': filter_the_weather,
        '3': http_filter
    }
    FUNCTIONS = {
        '1': print_dns,
        '2': weather_print_answer,
        '3': print_http
    }
    print('Welcome to Magshishark!')
    while True:
        user_choice = choise_and_menu()
        if user_choice == '0':
            break
        elif user_choice == '4':
            print('Sorry, this option is not supported...')
        else:
            print()
            try:
                sniff(lfilter=FILTER[user_choice], prn=FUNCTIONS[user_choice])
            except KeyboardInterrupt:
                pass
            except Exception as e:
                print('Error: ' + str(e))

if __name__ == "__main__":
    main()