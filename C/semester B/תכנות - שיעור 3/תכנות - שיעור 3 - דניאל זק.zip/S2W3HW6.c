#include <stdio.h>
#include <string.h>

#define PASSWORD "maGshimim2017"
#define STR_LEN 16
#define FALSE 0
#define TRUE !FALSE

int main(void)
{
	int pass = FALSE;
    char buff[STR_LEN] = { 0 };

    printf("Enter the password: ");
    fgets(buff, STR_LEN, stdin);

    if(strcmp(buff, PASSWORD))
    {
        printf ("Wrong Password \n");
    }
    else
    {
        printf ("Correct Password \n");
        pass = TRUE;
    }

    if(pass)
    {
        printf ("Access given to the secret files \n");
    }
	
	getchar();
    getchar();
    return 0;
}

/*
הבעיה היא שכאשר אנו שמים סיסמה ארוכה מ 16 אנו חורגים מהגבולות המערך ולכן אנו מתחילים לכתוב על זיכרון של משתנים אחרים 
ובגלל שהכרזנו על פאס ליד המערך אנו אנו משנים את הערך שלו ויכולים להפוך אותו מ 0 שזה לא נכון ל תו אחר שזה כבר יהיה נכון
ולכן זה יכניס אותנו לתנאי של האם לתת גישה
כל מה שצריך לעשות זה להגביל את הקלט של הסיסמה
*/