#include <stdio.h>

void swap(float* pa, float* pb);
void sort(float* pa, float* pb, float* pc);

int main(void)
{
    float num1 = 0, num2 = 0, num3 = 0;
    printf("Please enter num1, num2, num3: ");
    scanf("%f %f %f", &num1, &num2, &num3);
    sort(&num1, &num2, &num3);
    printf("After sorting: num1 = %.2f num2 = %.2f num3 = %.2f", num1, num2, num3);
    getchar();
    getchar();

    return 0;
}

/*
the function swaps two numbers
input: two pointes of float
output: none
*/
void swap(float* pa, float* pb)
{
    float temp = *pa;
    *pa = *pb;
    *pb = temp;
}

/*
the function sorting three number by smallest to bigest
input: three pointers of float
output: none
*/
void sort(float* pa, float* pb, float* pc)
{
    while(*pa > *pc || *pa > *pb || *pb > *pc)
    {
        if(*pa > *pc)
        {
            swap(pa, pc);
        }
        if(*pa > *pb)
        {
            swap(pa, pb);
        }
        if(*pb > *pc)
        {
            swap(pb, pc);
        }
    }
}