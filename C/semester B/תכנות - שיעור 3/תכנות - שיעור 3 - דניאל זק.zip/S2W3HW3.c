#include <stdio.h>
#include <string.h>

#define SIZE 50
#define FIRST_LETTER 'a'
#define LAST_LETTER 'z'
#define LETTERS 26
#define A_IN_ASCII 97
#define Z_IN_ASCII 122

void decrypt(char* cipher, int n);

int main()
{
    char cipher[SIZE] = {0};
    int key = 0;
    printf("Enter cipher to decrypt: ");
    fgets(cipher, SIZE, stdin);

    *(cipher + strcspn(cipher, "\n")) = 0;

    printf("Enter decryption key: ");
    scanf("%d", &key);

    decrypt(cipher, key);
    
    getchar();
    getchar();

    return 0;
}
/*
the function will decrypt a massage
input: string pointer, string size
output: none
*/
void decrypt(char* cipher, int n)
{
    char reverse[SIZE] = {0};
    int i = 0;
    int j = 0;
    char letter = ' ';

    for(i = SIZE - 1; i >= 0; i--)
    {
        reverse[j] = *(cipher + i);
        j++;
    }

    n = n % LETTERS;

    for(i = 0; i < SIZE; i++)
    {
        if(*(reverse + i) >= FIRST_LETTER && *(reverse + i) <= LAST_LETTER)
        {
            letter = *(reverse + i);
            letter = ((letter - A_IN_ASCII + n) % 26) + A_IN_ASCII;
            *(reverse + i) = letter;
        }
        
    }

    printf("Decrypted text: ");

    for(i = 0; i < SIZE; i++)
    {
        printf("%c", *(reverse + i));
    }
}