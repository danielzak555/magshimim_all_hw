#include <stdio.h>

#define SIZE 11

void printBeforeX(int* arr, int n, int* x);

int main()
{
    int arr[] = {4 ,8 ,6 ,2 ,1 ,3 ,5 ,7 ,8 ,9 ,5};
    int offset = 0;
    printf("Please enter an offset to search in the array's address domain: ");
    scanf("%d", &offset);
    printBeforeX(arr, SIZE, arr + offset);
    getchar();
    getchar();
    return 0;
}
/*
the function checkes if a pointer is pointing to one of the elementes of the array
input: array pointer, array size, a pointer
output: none
*/
void printBeforeX(int* arr, int n, int* x)
{
    if(x < arr + n && x >= arr)
    {
        printf("The array elements up to the index %d are: ", x - arr);
        while(arr <= x)
        {
            printf("%d ", *arr);
            arr++;
        }
    }
    else
    {
        printf("Index %d is out of the array range", x - arr);
    }

}