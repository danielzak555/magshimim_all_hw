#include <stdio.h>

void swap(float* pa, float* pb);

int main(void)
{
    float a = 0, b = 0;
    printf("Enter two numbers: ");
    scanf("%f %f", &a, &b);
    swap(&a, &b);
    printf("Swapped: %.2f %.2f", a, b);
    getchar();
    getchar();

    return 0;
}

/*
the function swaps two numbers
input: two pointes of int
output: none
*/
void swap(float* pa, float* pb)
{
    float temp = *pa;
    *pa = *pb;
    *pb = temp;
}
