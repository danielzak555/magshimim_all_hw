/*********************************
* Class: MAGSHIMIM C2			 *
* Week 2           				 *
* HW solution 			 		 *
**********************************/

#include <stdio.h>

void add(int* x, int* y, int* sum);

int main(void)
{
	int a = 0, b = 0, sum = 0;
	int *c = &b;//אנו שמים במצביע את הכתובת של בי לא את המשתנה עצמו
	printf("Enter two numbers: ");
	scanf("%d %d", &a, &b);
	getchar();
	add(&a, c, &sum);// סי זה כבר כתובת של בי ולכן צריך להוריד אמפרסאנד
	printf("The sum of a and b is: %d", sum);
	getchar();
	return 0;
}


void add(int* x, int* y, int* sum) 
{ 
	*sum = *x + *y; // לא קיים משתנה איקס וגם לא משתנה סאם ולכן צריך לשנות למצביע
}
// טיפ לדניאל החניך החתיך: שים לב שאתה תמיד מכריז על כל המשתנים בצורה נכונה וגם שאתה שם כוכבית מתי שצריך ולא שוכח וגם חשוב לזכור מה זה כל משתנה ולא לבלבל בטיפוסים שלהם