#include <stdio.h>

#define SIZE 11

int amountElements(int* arr, int n, int* x);

int main()
{
    int arr[] = {4 ,8 ,6 ,2 ,1 ,3 ,5 ,7 ,8 ,9 ,5};
    int offset = 0;
    printf("Please enter an index: ");
    scanf("%d", &offset);
    printf("%d", amountElements(arr, SIZE, arr + offset));
    getchar();
    getchar();
    return 0;
}
/*
the function return the amount of elementes from the start of the array to the pointer index
input: array pointer, array size, a pointer
output: the number of elementes
*/
int amountElements(int* arr, int n, int* x)
{
    return x - arr + 1;
}