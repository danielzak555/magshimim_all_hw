#include <stdio.h>

#define LEN 3

/* make a array
input: none
output: array pointer
*/
int* makeArray()
{
	int arr[] = {1,2,3};
    return arr;
}
/*
print array
input: array pointer, len
output: none
*/
void printArray(int* p, int len)
{
    int i = 0;
	for(i; i < len ; i++ ) 
	{
		printf("%d", *(p + i));
	}
}

int main(void)
{
    int* p = makeArray();
	printArray(p, LEN);
    getchar();
    getchar();
	return 0;
 }
/*
הבעייה היא נשאנו אכן מחזירים את המצביע למערך שמצביע למיקום בזיכרון של המערך
אבל לאחר הפונקציה איברי המערך נמחקים ואז בעצם אנו מצביעים על מקום בזיכרון שאנו כבר לא יודעים מה יש בו כי מחקנו ממנו את המערך
*/