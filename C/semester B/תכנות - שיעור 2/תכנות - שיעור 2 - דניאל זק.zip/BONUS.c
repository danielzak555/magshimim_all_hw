#include <stdio.h>

void getNums(int* p);

#define LEN 10

int main(void)
{
    int arr[LEN] = {0};
    int *p = arr;
    int i = 0;
    getNums(p);
    for(i = 0; i < LEN; i++)
    {
        printf("%d ", arr[i]);
    }
    getchar();
    getchar();  

    return 0;
}

/*
the function gets 10 numbers for a arr
input: one pointer of a arr
output: none
*/
void getNums(int* p)
{
    int i = 0;
    for(i = 0; i < LEN; i++)
    {
        printf("Enter value for index %d: ", i);
        scanf("%d", (p + i));
    }
}