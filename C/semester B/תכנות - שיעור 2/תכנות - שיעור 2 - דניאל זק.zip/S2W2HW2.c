/*********************************
* Class: MAGSHIMIM C2			 *
* Week 2           				 *
* HW solution   			 	 *
**********************************/
#include <stdio.h>
#include <time.h>

#define RANGE 10

void mystery(int* x,int* y);

int main(void)
{
	int a = 0, b = 0;
	srand(time(NULL)); // seed for rand
	a = (rand() % RANGE) + 1;
	b = (rand() % RANGE) + 1;
	printf("a: %d b: %d \n", a, b);
	
	mystery(&a, &b);
	printf("a: %d b: %d \n", a, b);

	return 0;
}

/*
the function checkes which one is bigger(a or b) and if a smaller it adding b to a else b = subtract b from a. 
input: two pointers of int
output: none
*/
void mystery(int* x, int* y)
{
	if(*x < *y)
	{
		*x = *x + *y;
	}
	else{
		*y = *x - *y;
	}
}
// כן הערך של אי או בי משתנה בהתאם למספר שמגרילים לכל אחד מהם , מה שאנחנו עודים זה לשלוח לפונקציה 
// את הכתובות בזיכרון של אי ובי, ואז מה שאנו עושים זה לבדוק לפי המצביעים את של אי ובי איזה אחד גדול יותר ואז
// לעשות פעולות מתמטיות  בהתאם בעזרת המצביעים של אי ובי
// וכאשר אנו עושים את החישוב אנו שומרים את התוצאה באחד מהמקומות בזיכרון או של אי או של בי(שומאים למצביע) ואז החישוב נשמר בהמקום בזיכרון
// ולכן בגלל שהוא נשמר ישירות שם אין סיבה להחזיר שום ערך כי אנו משנים את הערך ישירות מהזיכרון ואז כשאנו מדפיסים את אי ובי
// אחד מהם ישתנה בגלל ששינינו לו את הערך בזיכרון